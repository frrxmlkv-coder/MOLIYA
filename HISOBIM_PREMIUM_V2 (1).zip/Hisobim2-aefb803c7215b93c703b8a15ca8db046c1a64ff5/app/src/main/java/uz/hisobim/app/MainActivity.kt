package uz.hisobim.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {

    companion object {
        const val HOME = 0
        const val REPORTS = 1
        const val HISTORY = 2
        const val PROFILE = 3
        const val CREDITS = 4
        const val UTILITIES = 5
        const val ACCOUNTS = 6
        const val SMS_REQUEST = 101
    }

    private lateinit var store: Store
    private lateinit var body: FrameLayout
    private lateinit var nav: LinearLayout
    private val navViews = ArrayList<TextView>()

    private var page = HOME
    private var lastPage = -1
    private var curScroll: ScrollView? = null
    private var ready = false
    private var pendingImport = false
    private var accNames: Map<Long, String> = emptyMap()

    private var subTab = 0
    private val nowCal: Calendar = Calendar.getInstance()
    private var repYear = nowCal.get(Calendar.YEAR)
    private var repMonth = nowCal.get(Calendar.MONTH)

    private var histFilter = ""
    private var histQuery = ""
    private var histLimit = 60

    // ---------------------------------------------------------------- yordamchilar

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun bg(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun bottomRounded(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        val r = dp(radius).toFloat()
        g.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        return g
    }

    private fun tinted(c: Int, alpha: Int = 38): Int =
        Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c))

    private fun tv(value: String, size: Float, color: Int = Pal.text, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = value
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        return l
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun cardBox(pad: Int = 16): LinearLayout {
        val c = vbox()
        c.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        c.background = bg(Color.WHITE, 20)
        c.elevation = dp(2).toFloat()
        return c
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    private fun moneyField(hintText: String, initial: Long = 0L): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(20))
        e.addTextChangedListener(object : TextWatcher {
            var busy = false
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (busy || s == null) return
                busy = true
                val digits = s.toString().filter { it.isDigit() }
                val formatted = if (digits.isEmpty()) "" else Fmt.group(digits.toLongOrNull() ?: 0L)
                if (formatted != s.toString()) s.replace(0, s.length, formatted)
                busy = false
            }
        })
        if (initial > 0) e.setText(Fmt.group(initial))
        return e
    }

    private fun amountOf(e: EditText): Long = e.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0L

    private fun textField(hintText: String, initial: String = ""): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.setText(initial)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        return e
    }

    private fun spinner(items: List<String>): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        return s
    }

    private fun caption(text: String): TextView {
        val t = tv(text, 12f, Pal.gray, true)
        t.setPadding(0, dp(10), 0, 0)
        return t
    }

    private fun formBox(): LinearLayout {
        val f = vbox()
        f.setPadding(dp(22), dp(8), dp(22), dp(4))
        return f
    }

    private fun formDialog(title: String, form: View, okText: String, onOk: () -> Boolean): AlertDialog {
        val scroll = ScrollView(this)
        scroll.addView(form)
        val d = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setNegativeButton("Bekor qilish", null)
            .setPositiveButton(okText, null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (onOk()) d.dismiss()
            }
        }
        d.show()
        return d
    }

    private fun confirm(title: String, msg: String, yesText: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setNegativeButton("Yo‘q", null)
            .setPositiveButton(yesText) { _, _ -> onYes() }
            .show()
    }

    // ---------------------------------------------------------------- hayot sikli

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        buildShell()
        if (store.hasPin()) askPin() else render()
    }

    override fun onResume() {
        super.onResume()
        if (ready) render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != SMS_REQUEST) return
        var ok = grantResults.isNotEmpty()
        for (g in grantResults) if (g != PackageManager.PERMISSION_GRANTED) ok = false
        if (ok) {
            store.smsAuto = true
            toast("SMS ruxsati berildi")
            if (pendingImport) {
                pendingImport = false
                importInbox()
            }
        } else {
            pendingImport = false
            AlertDialog.Builder(this)
                .setTitle("SMS ruxsati berilmadi")
                .setMessage("Android 13 va undan yangisida APK’ni fayldan o‘rnatgan bo‘lsangiz, avval: Sozlamalar → Ilovalar → HISOBIM → ⋮ (yuqori o‘ng burchak) → “Cheklangan sozlamalarga ruxsat berish” ni bosing. So‘ng bu bo‘limdan ruxsatni qayta bering.")
                .setPositiveButton("Tushunarli", null)
                .show()
        }
        if (ready) render()
    }

    override fun onBackPressed() {
        if (page == CREDITS || page == UTILITIES) {
            navigate(HOME)
        } else if (page != HOME) {
            navigate(HOME)
        } else {
            super.onBackPressed()
        }
    }

    private fun askPin() {
        val f = EditText(this)
        f.hint = "PIN-kod"
        f.gravity = Gravity.CENTER
        f.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val box = formBox()
        box.addView(f)
        val d = AlertDialog.Builder(this)
            .setTitle("HISOBIM PREMIUM")
            .setMessage("PIN-kodni kiriting")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Kirish", null)
            .setNegativeButton("Chiqish") { _, _ -> finish() }
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (store.checkPin(f.text.toString())) {
                    d.dismiss()
                    render()
                } else {
                    toast("PIN-kod noto‘g‘ri")
                    f.setText("")
                }
            }
        }
        d.show()
    }

    // ---------------------------------------------------------------- qobiq va navigatsiya

    private fun buildShell() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Pal.purple)

        body = FrameLayout(this)
        body.setBackgroundColor(Pal.bg)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Color.WHITE)
        nav.gravity = Gravity.CENTER
        nav.elevation = dp(8).toFloat()

        val defs = listOf(
            Pair("🏠", "Asosiy"),
            Pair("📊", "Hisobot"),
            Pair("", ""),
            Pair("🧾", "Tarix"),
            Pair("👤", "Profil")
        )
        for (i in defs.indices) {
            if (i == 2) {
                val fab = tv("+", 30f, Color.WHITE, true)
                fab.gravity = Gravity.CENTER
                fab.background = bg(Pal.purple, 28)
                fab.setOnClickListener { quickAdd() }
                val holder = FrameLayout(this)
                holder.addView(fab, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
                nav.addView(holder, LinearLayout.LayoutParams(0, dp(66), 1f))
                navViews.add(fab)
            } else {
                val item = tv(defs[i].first + "\n" + defs[i].second, 12f, Pal.gray)
                item.gravity = Gravity.CENTER
                item.setPadding(0, dp(8), 0, dp(8))
                val target = when (i) {
                    0 -> HOME
                    1 -> REPORTS
                    3 -> HISTORY
                    else -> PROFILE
                }
                item.setOnClickListener { navigate(target) }
                nav.addView(item, LinearLayout.LayoutParams(0, dp(66), 1f))
                navViews.add(item)
            }
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        window.statusBarColor = Pal.purple
        window.navigationBarColor = Color.WHITE

        root.setOnApplyWindowInsetsListener { _, insets ->
            root.setPadding(0, insets.systemWindowInsetTop, 0, 0)
            nav.setPadding(0, 0, 0, insets.systemWindowInsetBottom)
            insets
        }
        root.requestApplyInsets()
    }

    private fun navigate(target: Int) {
        page = target
        render()
    }

    private fun highlightNav() {
        val active = when (page) {
            HOME, CREDITS, UTILITIES, ACCOUNTS -> 0
            REPORTS -> 1
            HISTORY -> 3
            else -> 4
        }
        for (i in navViews.indices) {
            if (i == 2) continue
            val v = navViews[i]
            v.setTextColor(if (i == active) Pal.purple else Pal.gray)
            v.setTypeface(null, if (i == active) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun render() {
        val keep = if (lastPage == page) (curScroll?.scrollY ?: 0) else 0
        lastPage = page
        ready = true
        accNames = store.accounts().associate { it.id to it.name }
        body.removeAllViews()
        val content: View = when (page) {
            REPORTS -> reportsPage()
            HISTORY -> historyPage()
            PROFILE -> profilePage()
            CREDITS -> creditsPage()
            UTILITIES -> utilitiesPage()
            ACCOUNTS -> accountsPage()
            else -> homePage()
        }
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(content)
        curScroll = scroll
        body.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        scroll.post { scroll.scrollTo(0, keep) }
        highlightNav()
    }

    private fun titleBar(title: String, subtitle: String, back: Boolean): View {
        val bar = hbox()
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(18), dp(14), dp(18), dp(20))
        bar.background = bottomRounded(Pal.purple, 28)
        if (back) {
            val b = tv("←", 26f, Color.WHITE, true)
            b.setPadding(0, 0, dp(14), 0)
            b.setOnClickListener { navigate(HOME) }
            bar.addView(b)
        }
        val col = vbox()
        col.addView(tv(title, 22f, Color.WHITE, true))
        if (subtitle.isNotEmpty()) col.addView(tv(subtitle, 13f, Color.argb(210, 255, 255, 255)))
        bar.addView(col, lp(0, -2, 1f))
        return bar
    }

    private fun sectionTitle(text: String, action: String = "", onAction: (() -> Unit)? = null): View {
        val row = hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(18), dp(20), dp(8))
        row.addView(tv(text, 17f, Pal.text, true), lp(0, -2, 1f))
        if (action.isNotEmpty() && onAction != null) {
            val a = tv(action, 14f, Pal.purple, true)
            a.setOnClickListener { onAction() }
            row.addView(a)
        }
        return row
    }

    private fun pad(v: View, side: Int = 16, top: Int = 0, bottom: Int = 0): View {
        val w = FrameLayout(this)
        w.setPadding(dp(side), dp(top), dp(side), dp(bottom))
        w.addView(v, FrameLayout.LayoutParams(-1, -2))
        return w
    }

    private fun bar(pct: Int, color: Int): View {
        val p = Math.max(0, Math.min(100, pct))
        val track = hbox()
        track.background = bg(Pal.line, 4)
        val fill = View(this)
        fill.background = bg(color, 4)
        track.addView(fill, LinearLayout.LayoutParams(0, dp(8), p.toFloat()))
        track.addView(View(this), LinearLayout.LayoutParams(0, dp(8), (100 - p).toFloat()))
        return track
    }

    // ---------------------------------------------------------------- umumiy qismlar

    private fun tile(icon: String, name: String, color: Int, action: () -> Unit): View {
        val box = vbox()
        box.gravity = Gravity.CENTER
        box.background = bg(Color.WHITE, 18)
        box.elevation = dp(2).toFloat()
        box.setOnClickListener { action() }
        val circle = tv(icon, 21f)
        circle.gravity = Gravity.CENTER
        circle.background = bg(tinted(color), 24)
        box.addView(circle, LinearLayout.LayoutParams(dp(46), dp(46)))
        val title = tv(name, 11.5f, Pal.text, true)
        title.gravity = Gravity.CENTER
        title.setPadding(0, dp(6), 0, 0)
        box.addView(title)
        return box
    }

    private fun tileRow(vararg tiles: View): View {
        val row = hbox()
        for (t in tiles) {
            row.addView(t, lp(0, dp(92), 1f, 4, 4, 4, 4))
        }
        return row
    }

    private fun txStyle(t: Tx): Pair<String, Int> {
        return when (t.type) {
            Types.INCOME -> Pair(Cats.icon(t.category), Pal.green)
            Types.TRANSFER -> Pair("🔁", Pal.blue)
            Types.CREDIT -> Pair("🏦", Pal.purple)
            else -> Pair(Cats.icon(t.category), Pal.red)
        }
    }

    private fun txRow(t: Tx): View {
        val style = txStyle(t)
        val row = hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(11), dp(14), dp(11))
        row.background = bg(Color.WHITE, 16)
        row.elevation = dp(1).toFloat()
        row.setOnClickListener { txDetail(t) }

        val icon = tv(style.first, 18f)
        icon.gravity = Gravity.CENTER
        icon.background = bg(tinted(style.second), 20)
        row.addView(icon, lp(dp(42), dp(42), 0f, 0, 0, 12, 0))

        val col = vbox()
        col.addView(tv(if (t.type == Types.INCOME || t.type == Types.EXPENSE) t.category else t.type, 15f, Pal.text, true))
        val accName = if (accNames.size > 1) accNames[t.accountId] else null
        val sub = (if (t.note.isNotBlank()) t.note + " • " else "") + (if (accName != null) accName + " • " else "") + Fmt.dateTime(t.time)
        col.addView(tv(sub, 12f, Pal.gray))
        row.addView(col, lp(0, -2, 1f))

        val sign = if (t.isIncome) "+" else "−"
        row.addView(tv(sign + Fmt.group(t.amount), 15f, if (t.isIncome) Pal.green else Pal.red, true))
        return row
    }

    private fun txDetail(t: Tx) {
        val msg = "Turi: ${t.type}\n" +
            "Toifa: ${t.category}\n" +
            "Summa: ${Fmt.money(t.amount)}\n" +
            (if (t.note.isNotBlank()) "Izoh: ${t.note}\n" else "") +
            "Sana: ${Fmt.dateTime(t.time)}"
        AlertDialog.Builder(this)
            .setTitle("Operatsiya")
            .setMessage(msg)
            .setPositiveButton("Yopish", null)
            .setNegativeButton("O‘chirish") { _, _ ->
                confirm(
                    "Operatsiyani o‘chirish",
                    "Operatsiya o‘chiriladi va balans qayta hisoblanadi.",
                    "O‘chirish"
                ) {
                    store.deleteTx(t.id)
                    toast("Operatsiya o‘chirildi")
                    render()
                }
            }
            .show()
    }

    private fun categoryBars(items: List<Pair<String, Long>>, total: Long, limit: Int): View {
        val box = cardBox()
        if (items.isEmpty() || total <= 0) {
            box.addView(tv("Hozircha ma’lumot yo‘q", 14f, Pal.gray))
            return box
        }
        var idx = 0
        for (item in items) {
            if (idx >= limit) break
            val pct = Math.round(item.second * 100.0 / total).toInt()
            val color = Pal.chart[idx % Pal.chart.size]
            val head = hbox()
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(tv(Cats.icon(item.first) + "  " + item.first, 14f, Pal.text, true), lp(0, -2, 1f))
            head.addView(tv(Fmt.group(item.second) + "  •  " + pct + "%", 13f, Pal.gray))
            box.addView(head, lp(-1, -2, 0f, 0, if (idx == 0) 0 else 12, 0, 6))
            box.addView(bar(pct, color))
            idx++
        }
        return box
    }

    // ---------------------------------------------------------------- Asosiy sahifa

    private fun homePage(): View {
        val all = store.transactions()
        val cal = Calendar.getInstance()
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH)
        val monthList = monthTx(all, y, m)
        val sum = summarize(monthList)
        val col = vbox()

        // --- sarlavha va balans
        val header = vbox()
        header.setPadding(dp(22), dp(16), dp(22), dp(26))
        header.background = bottomRounded(Pal.purple, 34)

        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val greet = if (hour < 5) "Xayrli tun" else if (hour < 12) "Xayrli tong" else if (hour < 18) "Xayrli kun" else "Xayrli kech"

        val titleRow = hbox()
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val titles = vbox()
        titles.addView(tv("HISOBIM", 28f, Color.WHITE, true))
        titles.addView(tv(greet + "! Shaxsiy moliya hisobingiz", 14f, Color.argb(215, 255, 255, 255)))
        titleRow.addView(titles, lp(0, -2, 1f))
        val chip = tv("PREMIUM", 11f, Pal.purpleDark, true)
        chip.gravity = Gravity.CENTER
        chip.setPadding(dp(10), dp(5), dp(10), dp(5))
        chip.background = bg(Pal.gold, 12)
        titleRow.addView(chip)
        header.addView(titleRow)

        val balCard = vbox()
        balCard.setPadding(dp(20), dp(18), dp(20), dp(18))
        balCard.background = bg(Color.WHITE, 24)
        balCard.addView(tv("Joriy balans", 15f, Pal.gray))
        val bal = store.balance
        balCard.addView(tv(Fmt.money(bal), 31f, if (bal < 0) Pal.red else Pal.purple, true))
        val mini = hbox()
        mini.addView(tv("↑ " + Fmt.group(sum.income), 13f, Pal.green, true), lp(0, -2, 1f))
        mini.addView(tv("↓ " + Fmt.group(sum.out), 13f, Pal.red, true), lp(0, -2, 1f))
        balCard.addView(space(6))
        balCard.addView(mini)
        balCard.addView(tv("${Fmt.months[m]} oyi bo‘yicha", 12f, Pal.gray))
        header.addView(balCard, lp(-1, -2, 0f, 0, 18, 0, 0))
        col.addView(header)

        // --- tugmalar
        val grid = vbox()
        grid.setPadding(dp(12), dp(16), dp(12), dp(0))
        grid.addView(
            tileRow(
                tile("➕", "Kirim", Pal.green) { addIncomeExpense(true) },
                tile("➖", "Chiqim", Pal.red) { addIncomeExpense(false) },
                tile("🔁", "O‘tkazma", Pal.blue) { transfer() },
                tile("🏦", "Kreditlar", Pal.purple) { navigate(CREDITS) }
            )
        )
        grid.addView(
            tileRow(
                tile("💡", "Kommunal", Pal.orange) { navigate(UTILITIES) },
                tile("📑", "Hisobot", Pal.purple) { subTab = 0; navigate(REPORTS) },
                tile("📈", "Statistika", Pal.orange) { subTab = 1; navigate(REPORTS) },
                tile("🥧", "Taqsimot", Pal.blue) { subTab = 2; navigate(REPORTS) }
            )
        )
        col.addView(grid)

        // --- hisoblar
        val accList = store.accounts()
        col.addView(sectionTitle("Hisoblarim", "Boshqarish") { navigate(ACCOUNTS) })
        val accBox = cardBox()
        for (i in accList.indices) {
            val a = accList[i]
            val row = hbox()
            row.gravity = Gravity.CENTER_VERTICAL
            val label = (if (a.last4.isNotEmpty()) "💳  " else "💵  ") + a.name
            row.addView(tv(label, 15f, Pal.text, true), lp(0, -2, 1f))
            row.addView(tv(Fmt.money(a.balance), 15f, if (a.balance < 0) Pal.red else Pal.purple, true))
            accBox.addView(row, lp(-1, -2, 0f, 0, if (i == 0) 0 else 12, 0, 0))
        }
        accBox.setOnClickListener { navigate(ACCOUNTS) }
        col.addView(pad(accBox))

        // --- yaqin kredit to‘lovlari
        val credits = store.credits()
        val due = ArrayList<Triple<Credit, Calendar, Int>>()
        for (c in credits) {
            val n = nextPayment(c) ?: continue
            val d = daysUntil(n)
            if (d <= 7) due.add(Triple(c, n, d))
        }
        if (due.isNotEmpty()) {
            col.addView(sectionTitle("⏰ Yaqin kredit to‘lovlari", "Kreditlar") { navigate(CREDITS) })
            val box = cardBox()
            for (i in due.indices) {
                val item = due[i]
                val row = hbox()
                row.gravity = Gravity.CENTER_VERTICAL
                val whenText = if (item.third <= 0) "Bugun" else "${item.third} kun qoldi"
                row.addView(tv(item.first.name, 15f, Pal.text, true), lp(0, -2, 1f))
                row.addView(tv(whenText + "  •  " + Fmt.moneyD(Math.min(item.first.monthly, item.first.left)), 13f, if (item.third <= 2) Pal.red else Pal.orange, true))
                box.addView(row, lp(-1, -2, 0f, 0, if (i == 0) 0 else 10, 0, 0))
            }
            box.setOnClickListener { navigate(CREDITS) }
            col.addView(pad(box))
        }

        // --- oylik limit
        val budget = store.budget
        col.addView(sectionTitle("Oylik limit"))
        val bBox = cardBox()
        if (budget > 0) {
            val pct = Math.round(sum.expense * 100.0 / budget).toInt()
            val color = if (pct >= 100) Pal.red else if (pct >= 80) Pal.orange else Pal.green
            val head = hbox()
            head.addView(tv(Fmt.money(sum.expense) + " / " + Fmt.money(budget), 14f, Pal.text, true), lp(0, -2, 1f))
            head.addView(tv("$pct%", 14f, color, true))
            bBox.addView(head)
            bBox.addView(space(8))
            bBox.addView(bar(pct, color))
            val left = budget - sum.expense
            bBox.addView(
                tv(
                    if (left >= 0) "Qolgan limit: " + Fmt.money(left) else "⚠ Limitdan oshdi: " + Fmt.money(-left),
                    13f, if (left >= 0) Pal.gray else Pal.red
                ).also { it.setPadding(0, dp(8), 0, 0) }
            )
        } else {
            bBox.addView(tv("Oylik xarajat limitini belgilang — hisobingiz nazoratda bo‘ladi.", 14f, Pal.gray))
            val b = tv("Limit belgilash", 14f, Pal.purple, true)
            b.setPadding(0, dp(10), 0, 0)
            bBox.addView(b)
        }
        bBox.setOnClickListener { setBudget() }
        col.addView(pad(bBox))

        // --- oylik ko‘rsatkichlar
        col.addView(sectionTitle("Oylik ko‘rsatkichlar", Fmt.monthName(y, m)) { subTab = 0; navigate(REPORTS) })
        val stats = cardBox(18)
        val sRow = hbox()
        val c1 = vbox()
        c1.addView(tv("↑ Kirim", 14f, Pal.green))
        c1.addView(tv(Fmt.money(sum.income), 18f, Pal.green, true))
        val c2 = vbox()
        c2.addView(tv("↓ Chiqim", 14f, Pal.red))
        c2.addView(tv(Fmt.money(sum.out), 18f, Pal.red, true))
        sRow.addView(c1, lp(0, -2, 1f))
        sRow.addView(c2, lp(0, -2, 1f))
        stats.addView(sRow)
        val netColor = if (sum.net >= 0) Pal.green else Pal.red
        stats.addView(
            tv("Sof natija: " + (if (sum.net > 0) "+" else "") + Fmt.money(sum.net), 14f, netColor, true)
                .also { it.setPadding(0, dp(12), 0, 0) }
        )
        col.addView(pad(stats))

        // --- xarajatlar taqsimoti
        col.addView(sectionTitle("Xarajatlar bo‘yicha taqsimot", "Batafsil") { subTab = 2; navigate(REPORTS) })
        var outTotal = 0L
        val byCat = outflowByCategory(monthList)
        for (p in byCat) outTotal += p.second
        col.addView(pad(categoryBars(byCat, outTotal, 5)))

        // --- so‘nggi operatsiyalar
        col.addView(sectionTitle("So‘nggi operatsiyalar", "Hammasi") { navigate(HISTORY) })
        val recent = all.sortedByDescending { it.time }.take(5)
        if (recent.isEmpty()) {
            val empty = cardBox()
            empty.addView(tv("Hozircha operatsiyalar mavjud emas. Boshlash uchun “Kirim” tugmasini bosing.", 14f, Pal.gray))
            col.addView(pad(empty))
        } else {
            for (t in recent) col.addView(pad(txRow(t), 16, 0, 8))
        }
        col.addView(space(24))
        return col
    }

    // ---------------------------------------------------------------- operatsiyalar

    private fun quickAdd() {
        val items = arrayOf("➕  Kirim", "➖  Chiqim", "🔁  O‘tkazma", "💡  Kommunal to‘lov", "🏦  Kredit to‘lovi")
        AlertDialog.Builder(this)
            .setTitle("Yangi operatsiya")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> addIncomeExpense(true)
                    1 -> addIncomeExpense(false)
                    2 -> transfer()
                    3 -> navigate(UTILITIES)
                    else -> navigate(CREDITS)
                }
            }
            .show()
    }

    private fun accountSpinner(accs: List<Account>): Spinner =
        spinner(accs.map { it.name + "  •  " + Fmt.group(it.balance) })

    private fun addIncomeExpense(isIncome: Boolean) {
        val form = formBox()
        val amount = moneyField("Summa (so‘m)")
        val cats = if (isIncome) Cats.income else Cats.expense
        val catSpinner = spinner(cats)
        val note = textField("Izoh (ixtiyoriy)")
        val accs = store.accounts()
        val accSpinner = accountSpinner(accs)
        form.addView(caption("HISOB / KARTA"))
        form.addView(accSpinner)
        form.addView(caption("SUMMA"))
        form.addView(amount)
        form.addView(caption("TOIFA"))
        form.addView(catSpinner)
        form.addView(caption("IZOH"))
        form.addView(note)

        formDialog(if (isIncome) "Kirim qo‘shish" else "Chiqim qo‘shish", form, "Saqlash") {
            val value = amountOf(amount)
            if (value <= 0) {
                toast("Summani to‘g‘ri kiriting")
                false
            } else if (!isIncome && value > accs[accSpinner.selectedItemPosition].balance) {
                toast("Tanlangan hisobda mablag‘ yetarli emas")
                false
            } else {
                store.addTx(
                    if (isIncome) Types.INCOME else Types.EXPENSE,
                    value,
                    cats[catSpinner.selectedItemPosition],
                    note.text.toString().trim(),
                    accs[accSpinner.selectedItemPosition].id
                )
                toast(if (isIncome) "Kirim saqlandi" else "Chiqim saqlandi")
                checkBudgetWarning()
                render()
                true
            }
        }
    }

    private fun checkBudgetWarning() {
        val budget = store.budget
        if (budget <= 0) return
        val c = Calendar.getInstance()
        val s = summarize(monthTx(store.transactions(), c.get(Calendar.YEAR), c.get(Calendar.MONTH)))
        if (s.expense > budget) toast("⚠ Oylik xarajat limitidan oshdingiz!")
    }

    private fun transfer() {
        val form = formBox()
        val amount = moneyField("Summa (so‘m)")
        val to = textField("Kimga / izoh")
        val accs = store.accounts()
        val accSpinner = accountSpinner(accs)
        form.addView(caption("QAYSI HISOBDAN"))
        form.addView(accSpinner)
        form.addView(caption("SUMMA"))
        form.addView(amount)
        form.addView(caption("KIMGA / IZOH"))
        form.addView(to)
        formDialog("Pul o‘tkazish", form, "O‘tkazish") {
            val value = amountOf(amount)
            if (value <= 0) {
                toast("Summani to‘g‘ri kiriting")
                false
            } else if (value > accs[accSpinner.selectedItemPosition].balance) {
                toast("Tanlangan hisobda mablag‘ yetarli emas")
                false
            } else {
                val note = to.text.toString().trim().ifEmpty { "Pul o‘tkazmasi" }
                store.addTx(Types.TRANSFER, value, "O‘tkazma", note, accs[accSpinner.selectedItemPosition].id)
                toast("O‘tkazma qayd etildi")
                render()
                true
            }
        }
    }

    private fun setBudget() {
        val form = formBox()
        val field = moneyField("Oylik limit (so‘m)", store.budget)
        form.addView(tv("Oylik xarajat limiti. 0 yoki bo‘sh qoldirsangiz, limit o‘chiriladi.", 13f, Pal.gray))
        form.addView(field)
        formDialog("Oylik limit", form, "Saqlash") {
            store.budget = amountOf(field)
            toast(if (store.budget > 0) "Limit saqlandi" else "Limit o‘chirildi")
            render()
            true
        }
    }

    // ---------------------------------------------------------------- Kommunal

    private fun utilitiesPage(): View {
        val all = store.transactions()
        val c = Calendar.getInstance()
        val monthList = monthTx(all, c.get(Calendar.YEAR), c.get(Calendar.MONTH)).filter { it.category == "Kommunal" }
        var total = 0L
        val perType = HashMap<String, Long>()
        for (t in monthList) {
            total += t.amount
            val key = t.note.substringBefore(" • ")
            perType[key] = (perType[key] ?: 0L) + t.amount
        }

        val col = vbox()
        col.addView(titleBar("Kommunal to‘lovlar", "Bu oy: " + Fmt.money(total), true))
        col.addView(sectionTitle("To‘lov turini tanlang"))

        val grid = vbox()
        grid.setPadding(dp(12), 0, dp(12), 0)
        var i = 0
        val list = Cats.utilities
        while (i < list.size) {
            val row = hbox()
            for (j in i until Math.min(i + 2, list.size)) {
                val name = list[j]
                val box = vbox()
                box.setPadding(dp(14), dp(14), dp(14), dp(14))
                box.background = bg(Color.WHITE, 18)
                box.elevation = dp(2).toFloat()
                box.addView(tv(Cats.icon(name) + "  " + name, 15f, Pal.text, true))
                val spent = perType[name] ?: 0L
                box.addView(tv(if (spent > 0) "Bu oy: " + Fmt.money(spent) else "To‘lov qilinmagan", 12f, if (spent > 0) Pal.green else Pal.gray))
                box.setOnClickListener { payUtility(name) }
                row.addView(box, lp(0, -2, 1f, 4, 4, 4, 4))
            }
            if (i + 1 >= list.size) row.addView(View(this), lp(0, 1, 1f, 4, 4, 4, 4))
            grid.addView(row)
            i += 2
        }
        col.addView(grid)

        col.addView(sectionTitle("Kommunal to‘lovlar tarixi"))
        val history = all.filter { it.category == "Kommunal" }.sortedByDescending { it.time }.take(15)
        if (history.isEmpty()) {
            val empty = cardBox()
            empty.addView(tv("Hozircha kommunal to‘lovlar yo‘q.", 14f, Pal.gray))
            col.addView(pad(empty))
        } else {
            for (t in history) col.addView(pad(txRow(t), 16, 0, 8))
        }
        col.addView(space(24))
        return col
    }

    private fun payUtility(name: String) {
        val form = formBox()
        val amount = moneyField("To‘lov summasi (so‘m)")
        val note = textField("Izoh (ixtiyoriy)")
        val accs = store.accounts()
        val accSpinner = accountSpinner(accs)
        form.addView(caption("HISOB / KARTA"))
        form.addView(accSpinner)
        form.addView(caption("SUMMA"))
        form.addView(amount)
        form.addView(caption("IZOH"))
        form.addView(note)
        formDialog(Cats.icon(name) + " " + name, form, "To‘lash") {
            val value = amountOf(amount)
            if (value <= 0) {
                toast("Summani to‘g‘ri kiriting")
                false
            } else if (value > accs[accSpinner.selectedItemPosition].balance) {
                toast("Tanlangan hisobda mablag‘ yetarli emas")
                false
            } else {
                val extra = note.text.toString().trim()
                store.addTx(
                    Types.EXPENSE, value, "Kommunal",
                    if (extra.isEmpty()) name else name + " • " + extra,
                    accs[accSpinner.selectedItemPosition].id
                )
                toast("To‘lov saqlandi")
                checkBudgetWarning()
                render()
                true
            }
        }
    }

    // ---------------------------------------------------------------- Hisobot / Statistika / Taqsimot

    private fun monthNav(): View {
        val row = hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        val prev = tv("‹", 30f, Pal.purple, true)
        prev.setPadding(dp(18), 0, dp(18), 0)
        prev.setOnClickListener {
            repMonth -= 1
            if (repMonth < 0) {
                repMonth = 11
                repYear -= 1
            }
            render()
        }
        val title = tv(Fmt.monthName(repYear, repMonth), 17f, Pal.text, true)
        title.gravity = Gravity.CENTER
        val isCurrent = repYear * 12 + repMonth >= nowCal.get(Calendar.YEAR) * 12 + nowCal.get(Calendar.MONTH)
        val next = tv("›", 30f, if (isCurrent) Pal.line else Pal.purple, true)
        next.setPadding(dp(18), 0, dp(18), 0)
        next.setOnClickListener {
            if (!isCurrent) {
                repMonth += 1
                if (repMonth > 11) {
                    repMonth = 0
                    repYear += 1
                }
                render()
            }
        }
        row.addView(prev)
        row.addView(title, lp(0, -2, 1f))
        row.addView(next)
        return row
    }

    private fun reportsPage(): View {
        val col = vbox()
        col.addView(titleBar("Hisobotlar", "Moliyaviy tahlil", false))

        val seg = hbox()
        seg.setPadding(dp(4), dp(4), dp(4), dp(4))
        seg.background = bg(Color.WHITE, 14)
        val names = listOf("Hisobot", "Statistika", "Taqsimot")
        for (i in names.indices) {
            val b = tv(names[i], 14f, if (i == subTab) Color.WHITE else Pal.purple, true)
            b.gravity = Gravity.CENTER
            b.setPadding(0, dp(10), 0, dp(10))
            if (i == subTab) b.background = bg(Pal.purple, 10)
            b.setOnClickListener {
                subTab = i
                render()
            }
            seg.addView(b, lp(0, -2, 1f))
        }
        col.addView(pad(seg, 16, 16, 4))

        val all = store.transactions()
        when (subTab) {
            1 -> statsBody(col, all)
            2 -> {
                col.addView(monthNav())
                distBody(col, all)
            }
            else -> {
                col.addView(monthNav())
                reportBody(col, all)
            }
        }
        col.addView(space(24))
        return col
    }

    private fun statRow(label: String, value: String, color: Int = Pal.text): View {
        val row = hbox()
        row.setPadding(0, dp(6), 0, dp(6))
        row.addView(tv(label, 14f, Pal.gray), lp(0, -2, 1f))
        row.addView(tv(value, 14f, color, true))
        return row
    }

    private fun reportBody(col: LinearLayout, all: List<Tx>) {
        val list = monthTx(all, repYear, repMonth)
        val s = summarize(list)

        val hero = vbox()
        hero.setPadding(dp(20), dp(18), dp(20), dp(18))
        hero.background = bg(Pal.purple, 22)
        hero.addView(tv("SOF NATIJA", 12f, Color.argb(210, 255, 255, 255), true))
        hero.addView(tv((if (s.net > 0) "+" else "") + Fmt.money(s.net), 28f, Color.WHITE, true))
        val rate = if (s.income > 0) Math.round(s.net * 100.0 / s.income).toInt() else 0
        hero.addView(
            tv(
                if (s.income > 0) "Jamg‘arma darajasi: $rate%" else "Bu oy kirim kiritilmagan",
                13f, Color.argb(220, 255, 255, 255)
            )
        )
        col.addView(pad(hero, 16, 6, 0))

        col.addView(sectionTitle("Batafsil"))
        val box = cardBox()
        box.addView(statRow("Jami kirim", Fmt.money(s.income), Pal.green))
        box.addView(statRow("Xarajatlar", Fmt.money(s.expense), Pal.red))
        box.addView(statRow("O‘tkazmalar", Fmt.money(s.transfer), Pal.blue))
        box.addView(statRow("Kredit to‘lovlari", Fmt.money(s.credit), Pal.purple))
        box.addView(statRow("Jami chiqim", Fmt.money(s.out), Pal.red))
        box.addView(statRow("Operatsiyalar soni", s.count.toString() + " ta"))
        val expenses = list.filter { it.type == Types.EXPENSE }
        if (expenses.isNotEmpty()) {
            val biggest = expenses.maxByOrNull { it.amount }
            if (biggest != null) {
                box.addView(statRow("Eng katta xarajat", biggest.category + " • " + Fmt.group(biggest.amount)))
            }
        }
        val daysInMonth = Calendar.getInstance().also {
            it.set(Calendar.DAY_OF_MONTH, 1)
            it.set(Calendar.YEAR, repYear)
            it.set(Calendar.MONTH, repMonth)
        }.getActualMaximum(Calendar.DAY_OF_MONTH)
        val isNow = repYear == nowCal.get(Calendar.YEAR) && repMonth == nowCal.get(Calendar.MONTH)
        val dayDiv = if (isNow) Math.max(1, Calendar.getInstance().get(Calendar.DAY_OF_MONTH)) else daysInMonth
        box.addView(statRow("O‘rtacha kunlik chiqim", Fmt.money(s.out / dayDiv)))
        col.addView(pad(box))

        col.addView(sectionTitle("Eng ko‘p xarajat qilingan toifalar"))
        var total = 0L
        val byCat = outflowByCategory(list)
        for (p in byCat) total += p.second
        col.addView(pad(categoryBars(byCat, total, 5)))

        val share = tv("📤  Hisobotni ulashish", 15f, Color.WHITE, true)
        share.gravity = Gravity.CENTER
        share.setPadding(0, dp(14), 0, dp(14))
        share.background = bg(Pal.purple, 16)
        share.setOnClickListener {
            val text = "HISOBIM — ${Fmt.monthName(repYear, repMonth)} hisoboti\n\n" +
                "Kirim: ${Fmt.money(s.income)}\n" +
                "Xarajatlar: ${Fmt.money(s.expense)}\n" +
                "O‘tkazmalar: ${Fmt.money(s.transfer)}\n" +
                "Kredit to‘lovlari: ${Fmt.money(s.credit)}\n" +
                "Jami chiqim: ${Fmt.money(s.out)}\n" +
                "Sof natija: ${Fmt.money(s.net)}\n" +
                "Operatsiyalar: ${s.count} ta\n" +
                "Joriy balans: ${Fmt.money(store.balance)}"
            shareText("Hisobot", text)
        }
        col.addView(pad(share, 16, 16, 0))
    }

    private fun statsBody(col: LinearLayout, all: List<Tx>) {
        val curKey = nowCal.get(Calendar.YEAR) * 12 + nowCal.get(Calendar.MONTH)
        val labels = ArrayList<String>()
        val incomes = ArrayList<Long>()
        val expenses = ArrayList<Long>()
        val sums = ArrayList<Summary>()
        for (k in (curKey - 5)..curKey) {
            val y = k / 12
            val m = k % 12
            val s = summarize(monthTx(all, y, m))
            labels.add(Fmt.shortMonths[m])
            incomes.add(s.income)
            expenses.add(s.out)
            sums.add(s)
        }
        col.addView(sectionTitle("So‘nggi 6 oy: kirim va chiqim"))
        val chartBox = cardBox()
        val chart = BarChartView(this)
        chart.labels = labels
        chart.income = incomes
        chart.expense = expenses
        chartBox.addView(chart, LinearLayout.LayoutParams(-1, dp(210)))
        val legend = hbox()
        legend.gravity = Gravity.CENTER
        legend.addView(tv("●  Kirim", 13f, Pal.green, true), lp(-2, -2, 0f, 0, 0, 18, 0))
        legend.addView(tv("●  Chiqim", 13f, Pal.red, true))
        chartBox.addView(legend)
        col.addView(pad(chartBox))

        var ti = 0L
        var to = 0L
        var active = 0
        for (i in sums.indices) {
            ti += sums[i].income
            to += sums[i].out
            if (sums[i].count > 0) active++
        }
        val div = Math.max(1, active)
        col.addView(sectionTitle("O‘rtacha ko‘rsatkichlar"))
        val avg = cardBox()
        avg.addView(statRow("O‘rtacha oylik kirim", Fmt.money(ti / div), Pal.green))
        avg.addView(statRow("O‘rtacha oylik chiqim", Fmt.money(to / div), Pal.red))
        avg.addView(statRow("6 oylik sof natija", (if (ti - to > 0) "+" else "") + Fmt.money(ti - to), if (ti - to >= 0) Pal.green else Pal.red))
        col.addView(pad(avg))

        col.addView(sectionTitle("Oylar bo‘yicha"))
        val table = cardBox()
        for (i in sums.indices.reversed()) {
            val k = curKey - 5 + i
            val s = sums[i]
            val row = hbox()
            row.setPadding(0, dp(7), 0, dp(7))
            row.addView(tv(Fmt.months[k % 12], 14f, Pal.text, true), lp(0, -2, 1f))
            row.addView(tv((if (s.net > 0) "+" else "") + Fmt.group(s.net), 14f, if (s.net >= 0) Pal.green else Pal.red, true))
            table.addView(row)
        }
        col.addView(pad(table))
    }

    private fun distBody(col: LinearLayout, all: List<Tx>) {
        val list = monthTx(all, repYear, repMonth)
        val byCat = outflowByCategory(list)
        var total = 0L
        for (p in byCat) total += p.second

        col.addView(sectionTitle("Chiqimlar taqsimoti"))
        val box = cardBox()
        if (total <= 0) {
            box.addView(tv("Bu oy uchun chiqimlar yo‘q.", 14f, Pal.gray))
            col.addView(pad(box))
            return
        }
        val pie = PieView(this)
        pie.values = byCat.map { it.second }
        pie.centerTop = "Jami"
        pie.centerBottom = Fmt.short(total)
        box.addView(pie, LinearLayout.LayoutParams(-1, dp(230)))
        for (i in byCat.indices) {
            val item = byCat[i]
            val pct = Math.round(item.second * 1000.0 / total) / 10.0
            val row = hbox()
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(7), 0, dp(7))
            val dot = View(this)
            dot.background = bg(Pal.chart[i % Pal.chart.size], 6)
            row.addView(dot, lp(dp(12), dp(12), 0f, 0, 0, 10, 0))
            row.addView(tv(Cats.icon(item.first) + " " + item.first, 14f, Pal.text, true), lp(0, -2, 1f))
            row.addView(tv(Fmt.group(item.second) + "  •  " + pct + "%", 13f, Pal.gray))
            box.addView(row)
        }
        col.addView(pad(box))
    }

    private fun shareText(subject: String, text: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_SUBJECT, subject)
        i.putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(i, "Ulashish"))
    }

    // ---------------------------------------------------------------- Tarix

    private fun historyPage(): View {
        val col = vbox()
        col.addView(titleBar("Operatsiyalar", "Barcha kirim va chiqimlar tarixi", false))

        val search = EditText(this)
        search.hint = "🔍  Qidirish (toifa, izoh, summa)"
        search.setText(histQuery)
        search.setSingleLine(true)
        search.setPadding(dp(16), dp(12), dp(16), dp(12))
        search.background = bg(Color.WHITE, 14)
        col.addView(pad(search, 16, 16, 8))

        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        val chips = hbox()
        chips.setPadding(dp(12), 0, dp(12), dp(8))
        val defs = listOf(
            Pair("Hammasi", ""),
            Pair("Kirim", Types.INCOME),
            Pair("Chiqim", Types.EXPENSE),
            Pair("O‘tkazma", Types.TRANSFER),
            Pair("Kredit", Types.CREDIT)
        )
        for (d in defs) {
            val on = histFilter == d.second
            val chip = tv(d.first, 13f, if (on) Color.WHITE else Pal.purple, true)
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            chip.background = bg(if (on) Pal.purple else Color.WHITE, 18)
            chip.setOnClickListener {
                histFilter = d.second
                histLimit = 60
                render()
            }
            chips.addView(chip, lp(-2, -2, 0f, 4, 0, 4, 0))
        }
        chipScroll.addView(chips)
        col.addView(chipScroll)

        val summary = tv("", 13f, Pal.gray, true)
        summary.setPadding(dp(22), dp(6), dp(22), dp(6))
        col.addView(summary)

        val listBox = vbox()
        col.addView(listBox)
        fillHistory(listBox, summary)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                histQuery = s?.toString() ?: ""
                histLimit = 60
                fillHistory(listBox, summary)
            }
        })
        col.addView(space(24))
        return col
    }

    private fun fillHistory(box: LinearLayout, summaryView: TextView) {
        box.removeAllViews()
        val q = histQuery.trim().lowercase()
        val filtered = store.transactions()
            .filter { histFilter.isEmpty() || it.type == histFilter }
            .filter {
                q.isEmpty() ||
                    it.category.lowercase().contains(q) ||
                    it.note.lowercase().contains(q) ||
                    it.type.lowercase().contains(q) ||
                    it.amount.toString().contains(q.replace(" ", ""))
            }
            .sortedByDescending { it.time }
        val s = summarize(filtered)
        summaryView.text = "${filtered.size} ta  •  Kirim ${Fmt.group(s.income)}  •  Chiqim ${Fmt.group(s.out)}"

        if (filtered.isEmpty()) {
            val empty = cardBox()
            empty.addView(tv("Operatsiyalar topilmadi.", 14f, Pal.gray))
            box.addView(pad(empty, 16, 4, 0))
            return
        }
        var lastDay = ""
        var shown = 0
        for (t in filtered) {
            if (shown >= histLimit) break
            val day = Fmt.dateOnly(t.time)
            if (day != lastDay) {
                val h = tv(day, 13f, Pal.gray, true)
                h.setPadding(dp(22), dp(12), dp(22), dp(6))
                box.addView(h)
                lastDay = day
            }
            box.addView(pad(txRow(t), 16, 0, 8))
            shown++
        }
        if (filtered.size > shown) {
            val more = tv("Yana ko‘rsatish (${filtered.size - shown})", 14f, Pal.purple, true)
            more.gravity = Gravity.CENTER
            more.setPadding(0, dp(14), 0, dp(14))
            more.setOnClickListener {
                histLimit += 60
                fillHistory(box, summaryView)
            }
            box.addView(more)
        }
    }

    // ---------------------------------------------------------------- Kreditlar

    private fun creditsPage(): View {
        val credits = store.credits()
        var total = 0.0
        var paid = 0.0
        var monthly = 0.0
        for (c in credits) {
            total += c.total
            paid += c.paid
            if (c.left > 0) monthly += Math.min(c.monthly, c.left)
        }
        val remaining = (total - paid).coerceAtLeast(0.0)

        val col = vbox()
        col.addView(titleBar("Kreditlarim", "Shaxsiy kredit boshqaruvi", true))

        val summary = vbox()
        summary.setPadding(dp(20), dp(18), dp(20), dp(18))
        summary.background = bg(Pal.purpleDark, 22)
        summary.addView(tv("UMUMIY QARZ QOLDIG‘I", 12f, Color.argb(210, 255, 255, 255), true))
        summary.addView(tv(Fmt.moneyD(remaining), 27f, Color.WHITE, true))
        summary.addView(tv("Jami kredit: " + Fmt.moneyD(total), 13f, Color.argb(220, 255, 255, 255)))
        summary.addView(tv("To‘langan: " + Fmt.moneyD(paid), 13f, Color.argb(220, 255, 255, 255)))
        col.addView(pad(summary, 16, 16, 0))

        val stats = hbox()
        val c1 = cardBox(14)
        c1.addView(tv("OYLIK TO‘LOV", 11f, Pal.gray, true))
        c1.addView(tv(Fmt.moneyD(monthly), 15f, Pal.purple, true))
        val c2 = cardBox(14)
        c2.addView(tv("KREDITLAR", 11f, Pal.gray, true))
        c2.addView(tv(credits.size.toString() + " ta", 15f, Pal.purple, true))
        stats.addView(c1, lp(0, -1, 1f, 0, 0, 5, 0))
        stats.addView(c2, lp(0, -1, 1f, 5, 0, 0, 0))
        col.addView(pad(stats, 16, 12, 0))

        col.addView(sectionTitle("Mening kreditlarim"))
        if (credits.isEmpty()) {
            val empty = cardBox()
            empty.addView(tv("Hozircha kredit mavjud emas.", 14f, Pal.gray))
            col.addView(pad(empty))
        }
        for (i in credits.indices) {
            col.addView(pad(creditCard(i, credits[i]), 16, 0, 12))
        }

        val add = tv("+  YANGI KREDIT QO‘SHISH", 15f, Color.WHITE, true)
        add.gravity = Gravity.CENTER
        add.setPadding(0, dp(15), 0, dp(15))
        add.background = bg(Pal.purple, 16)
        add.setOnClickListener { addCredit() }
        col.addView(pad(add, 16, 4, 0))
        col.addView(space(24))
        return col
    }

    private fun creditCard(index: Int, c: Credit): View {
        val box = cardBox()
        val head = hbox()
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv(c.name, 18f, Pal.purple, true), lp(0, -2, 1f))
        if (c.type.isNotBlank()) {
            val chip = tv(c.type, 11f, Pal.purple, true)
            chip.setPadding(dp(10), dp(4), dp(10), dp(4))
            chip.background = bg(tinted(Pal.purple), 10)
            head.addView(chip)
        }
        box.addView(head)
        box.addView(tv("Kredit summasi: " + Fmt.moneyD(c.total), 14f, Pal.text).also { it.setPadding(0, dp(6), 0, 0) })
        box.addView(tv("Qolgan qarz: " + Fmt.moneyD(c.left), 18f, if (c.left > 0) Pal.red else Pal.green, true).also { it.setPadding(0, dp(4), 0, 0) })
        box.addView(tv("To‘langan: " + Fmt.moneyD(c.paid), 14f, Pal.green))
        val rateText = if (c.rate == Math.floor(c.rate)) c.rate.toInt().toString() else c.rate.toString()
        box.addView(tv("Yillik foiz: $rateText%", 13f, Pal.gray))
        box.addView(tv("Oylik to‘lov: " + Fmt.moneyD(c.monthly), 13f, Pal.gray))
        if (c.left > 0 && c.monthly > 0) {
            val monthsLeft = Math.ceil(c.left / c.monthly).toInt()
            box.addView(tv("Taxminiy qolgan muddat: $monthsLeft oy", 13f, Pal.gray))
        }
        val next = nextPayment(c)
        if (next != null) {
            val d = daysUntil(next)
            val whenText = if (d <= 0) "bugun" else "$d kundan keyin"
            box.addView(
                tv(
                    "⏰ Keyingi to‘lov: " + Fmt.dateOnly(next.timeInMillis) + " ($whenText)",
                    13f, if (d <= 3) Pal.red else Pal.orange, true
                ).also { it.setPadding(0, dp(4), 0, 0) }
            )
        } else {
            box.addView(tv("✅ Kredit to‘liq to‘langan", 13f, Pal.green, true))
        }
        box.addView(tv("To‘lov bajarilishi: ${c.progress}%", 12f, Pal.purple, true).also { it.setPadding(0, dp(8), 0, dp(4)) })
        box.addView(bar(c.progress, Pal.green))

        val actions = hbox()
        val pay = tv("TO‘LOV QO‘SHISH", 13f, Color.WHITE, true)
        pay.gravity = Gravity.CENTER
        pay.setPadding(0, dp(12), 0, dp(12))
        pay.background = bg(Pal.green, 12)
        pay.setOnClickListener { addCreditPayment(index) }
        val del = tv("O‘CHIRISH", 13f, Color.WHITE, true)
        del.gravity = Gravity.CENTER
        del.setPadding(0, dp(12), 0, dp(12))
        del.background = bg(Pal.red, 12)
        del.setOnClickListener {
            confirm("Kreditni o‘chirish", "“${c.name}” krediti o‘chirilsinmi? Avval qilingan to‘lov operatsiyalari tarixda qoladi.", "Ha, o‘chirish") {
                val list = store.credits()
                if (index >= 0 && index < list.size) {
                    list.removeAt(index)
                    store.saveCredits(list)
                }
                toast("Kredit o‘chirildi")
                render()
            }
        }
        actions.addView(pay, lp(0, -2, 1f, 0, 12, 4, 0))
        actions.addView(del, lp(0, -2, 1f, 4, 12, 0, 0))
        box.addView(actions)
        return box
    }

    private fun addCredit() {
        val form = formBox()
        val bank = textField("Bank yoki kreditor nomi")
        val typeSpinner = spinner(Cats.creditTypes)
        val amount = moneyField("Kredit summasi (so‘m)")
        val rate = EditText(this)
        rate.hint = "Yillik foiz stavkasi (%)"
        rate.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val months = EditText(this)
        months.hint = "Kredit muddati (oy)"
        months.inputType = InputType.TYPE_CLASS_NUMBER
        val monthly = moneyField("Oylik to‘lov (bo‘sh bo‘lsa, avtomatik hisoblanadi)")
        val start = textField("Boshlanish sanasi (YYYY-MM-DD)", Fmt.today())
        start.inputType = InputType.TYPE_CLASS_TEXT
        val day = EditText(this)
        day.hint = "Har oyning to‘lov kuni (1-31)"
        day.inputType = InputType.TYPE_CLASS_NUMBER
        val paid = moneyField("Hozirgacha to‘langan summa")
        val purpose = textField("Kredit maqsadi (ixtiyoriy)")

        form.addView(caption("KREDITOR"))
        form.addView(bank)
        form.addView(caption("KREDIT TURI"))
        form.addView(typeSpinner)
        form.addView(caption("SUMMA VA FOIZ"))
        form.addView(amount)
        form.addView(rate)
        form.addView(caption("MUDDAT VA TO‘LOV"))
        form.addView(months)
        form.addView(monthly)
        form.addView(caption("SANALAR"))
        form.addView(start)
        form.addView(day)
        form.addView(caption("QO‘SHIMCHA"))
        form.addView(paid)
        form.addView(purpose)

        formDialog("Yangi kredit", form, "Saqlash") {
            val total = amountOf(amount).toDouble()
            val interest = rate.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
            val term = months.text.toString().toIntOrNull() ?: 0
            var monthlyAmount = amountOf(monthly).toDouble()
            val paidAmount = amountOf(paid).toDouble()
            val startText = start.text.toString().trim()
            var payDay = day.text.toString().toIntOrNull() ?: 0
            if (payDay == 0 && Fmt.isValidDate(startText)) payDay = startText.substring(8, 10).toInt()

            if (bank.text.isBlank()) {
                toast("Kreditor nomini kiriting")
                false
            } else if (total <= 0) {
                toast("Kredit summasini kiriting")
                false
            } else if (interest < 0 || interest > 300) {
                toast("Foiz stavkasi noto‘g‘ri")
                false
            } else if (term <= 0) {
                toast("Kredit muddatini (oy) kiriting")
                false
            } else if (!Fmt.isValidDate(startText)) {
                toast("Sanani YYYY-MM-DD ko‘rinishida kiriting")
                false
            } else if (payDay < 1 || payDay > 31) {
                toast("To‘lov kuni 1 dan 31 gacha bo‘lishi kerak")
                false
            } else if (paidAmount > total) {
                toast("To‘langan summa kredit summasidan katta bo‘lmasin")
                false
            } else {
                if (monthlyAmount <= 0) monthlyAmount = Math.round(annuity(total, interest, term)).toDouble()
                val list = store.credits()
                list.add(
                    Credit(
                        bank.text.toString().trim(),
                        Cats.creditTypes[typeSpinner.selectedItemPosition],
                        total, interest, term, monthlyAmount, startText, payDay, paidAmount,
                        purpose.text.toString().trim()
                    )
                )
                store.saveCredits(list)
                toast("Kredit saqlandi. Oylik to‘lov: " + Fmt.moneyD(monthlyAmount))
                render()
                true
            }
        }
    }

    private fun addCreditPayment(index: Int) {
        val list = store.credits()
        if (index < 0 || index >= list.size) return
        val c = list[index]
        if (c.left <= 0) {
            toast("Kredit to‘liq to‘langan!")
            return
        }
        val suggested = Math.min(Math.round(c.monthly), Math.ceil(c.left).toLong())
        val form = formBox()
        form.addView(tv("Qolgan qarz: " + Fmt.moneyD(c.left), 14f, Pal.red, true))
        val accs = store.accounts()
        val accSpinner = accountSpinner(accs)
        form.addView(caption("QAYSI HISOBDAN"))
        form.addView(accSpinner)
        val field = moneyField("To‘lov summasi (so‘m)", suggested)
        form.addView(caption("SUMMA"))
        form.addView(field)
        form.addView(tv("To‘lov tanlangan hisobdan yechiladi va chiqim sifatida hisobga olinadi.", 12f, Pal.gray).also { it.setPadding(0, dp(8), 0, 0) })
        formDialog("Kredit to‘lovi", form, "To‘lash") {
            val error = store.payCredit(index, amountOf(field), accs[accSpinner.selectedItemPosition].id)
            if (error != null) {
                toast(error)
                false
            } else {
                val after = store.credits()
                val closed = index < after.size && after[index].left <= 0
                toast(if (closed) "🎉 Kredit to‘liq yopildi!" else "To‘lov saqlandi")
                render()
                true
            }
        }
    }

    // ---------------------------------------------------------------- Profil

    private fun actionRow(icon: String, title: String, subtitle: String, color: Int = Pal.purple, onClick: () -> Unit): View {
        val row = hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(13), dp(14), dp(13))
        row.background = bg(Color.WHITE, 16)
        row.elevation = dp(1).toFloat()
        row.setOnClickListener { onClick() }
        val ic = tv(icon, 19f)
        ic.gravity = Gravity.CENTER
        ic.background = bg(tinted(color), 20)
        row.addView(ic, lp(dp(42), dp(42), 0f, 0, 0, 12, 0))
        val col = vbox()
        col.addView(tv(title, 15f, Pal.text, true))
        if (subtitle.isNotEmpty()) col.addView(tv(subtitle, 12f, Pal.gray))
        row.addView(col, lp(0, -2, 1f))
        row.addView(tv("›", 22f, Pal.gray))
        return row
    }

    private fun profilePage(): View {
        val col = vbox()
        col.addView(titleBar("Profil va sozlamalar", "HISOBIM PREMIUM  •  v2.0", false))

        val txCount = store.transactions().size
        val crCount = store.credits().size
        val info = cardBox()
        info.addView(statRow("Joriy balans", Fmt.money(store.balance), Pal.purple))
        info.addView(statRow("Operatsiyalar soni", "$txCount ta"))
        info.addView(statRow("Kreditlar soni", "$crCount ta"))
        info.addView(statRow("Oylik limit", if (store.budget > 0) Fmt.money(store.budget) else "belgilanmagan"))
        info.addView(statRow("PIN-kod", if (store.hasPin()) "yoqilgan" else "o‘chiq"))
        col.addView(pad(info, 16, 16, 0))

        col.addView(sectionTitle("Sozlamalar"))
        col.addView(pad(actionRow("🎯", "Oylik xarajat limiti", "Xarajatlarni nazorat qiling", Pal.orange) { setBudget() }, 16, 0, 8))
        col.addView(pad(actionRow("🔒", if (store.hasPin()) "PIN-kodni o‘zgartirish / o‘chirish" else "PIN-kod o‘rnatish", "Ilovaga kirishni himoyalang", Pal.blue) { pinSettings() }, 16, 0, 8))

        col.addView(sectionTitle("Zaxira nusxa"))
        col.addView(pad(actionRow("📤", "Zaxira nusxani ulashish", "Barcha ma’lumotlar matn ko‘rinishida", Pal.green) {
            shareText("HISOBIM zaxira nusxa", store.exportJson())
        }, 16, 0, 8))
        col.addView(pad(actionRow("📋", "Zaxira nusxani nusxalash", "Vaqtinchalik xotiraga (bufer) saqlanadi", Pal.green) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("HISOBIM", store.exportJson()))
            toast("Zaxira nusxa nusxalandi")
        }, 16, 0, 8))
        col.addView(pad(actionRow("📥", "Zaxira nusxadan tiklash", "Joriy ma’lumotlar almashtiriladi", Pal.purple) { restoreBackup() }, 16, 0, 8))

        col.addView(sectionTitle("Hisoblar va SMS"))
        col.addView(pad(actionRow("💳", "Hisoblar va kartalar", store.accounts().size.toString() + " ta hisob", Pal.blue) { navigate(ACCOUNTS) }, 16, 0, 8))
        col.addView(pad(actionRow("📩", "SMS’dan avtomatik qo‘shish: " + (if (store.smsAuto && hasSmsPermission()) "yoqilgan" else "o‘chiq"), if (hasSmsPermission()) "Bank SMS’lari kelishi bilan o‘zi qo‘shiladi" else "Ruxsat berilmagan — bosib yoqing", Pal.green) { toggleSms() }, 16, 0, 8))
        col.addView(pad(actionRow("🔄", "Eski SMS’larni import qilish", "So‘nggi 60 kundagi bank SMS’lari", Pal.blue) { importInbox() }, 16, 0, 8))
        col.addView(pad(actionRow("📝", "SMS matnini qo‘lda qo‘shish", "Nusxalab qo‘ying, ruxsat shart emas", Pal.purple) { pasteSms() }, 16, 0, 8))

        col.addView(sectionTitle("Xavfli hudud"))
        col.addView(pad(actionRow("🗑", "Barcha ma’lumotlarni o‘chirish", "Bu amalni qaytarib bo‘lmaydi", Pal.red) {
            confirm("Barcha ma’lumotlarni o‘chirish", "Balans, operatsiyalar, kreditlar va sozlamalar butunlay o‘chiriladi. Avval zaxira nusxa oling. Davom etasizmi?", "Ha, o‘chirish") {
                store.resetAll()
                toast("Ma’lumotlar o‘chirildi")
                navigate(HOME)
            }
        }, 16, 0, 8))

        val about = tv("HISOBIM PREMIUM\nMa’lumotlar faqat shu qurilmada saqlanadi. Ilovani o‘chirishdan oldin zaxira nusxa oling.", 12f, Pal.gray)
        about.gravity = Gravity.CENTER
        about.setPadding(dp(24), dp(16), dp(24), dp(24))
        col.addView(about)
        return col
    }

    private fun pinSettings() {
        val form = formBox()
        val pin = EditText(this)
        pin.hint = if (store.hasPin()) "Yangi PIN-kod (4–6 raqam)" else "PIN-kod (4–6 raqam)"
        pin.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        pin.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(6))
        form.addView(pin)
        if (store.hasPin()) {
            val off = tv("PIN-kodni o‘chirish", 14f, Pal.red, true)
            off.setPadding(0, dp(16), 0, dp(6))
            form.addView(off)
            val d = formDialog("PIN-kod", form, "Saqlash") {
                val v = pin.text.toString()
                if (v.length < 4) {
                    toast("PIN-kod kamida 4 raqamdan iborat bo‘lsin")
                    false
                } else {
                    store.setPin(v)
                    toast("PIN-kod o‘zgartirildi")
                    render()
                    true
                }
            }
            off.setOnClickListener {
                store.setPin(null)
                toast("PIN-kod o‘chirildi")
                d.dismiss()
                render()
            }
        } else {
            formDialog("PIN-kod o‘rnatish", form, "Saqlash") {
                val v = pin.text.toString()
                if (v.length < 4) {
                    toast("PIN-kod kamida 4 raqamdan iborat bo‘lsin")
                    false
                } else {
                    store.setPin(v)
                    toast("PIN-kod o‘rnatildi")
                    render()
                    true
                }
            }
        }
    }

    private fun restoreBackup() {
        val form = formBox()
        val field = EditText(this)
        field.hint = "Zaxira nusxa matnini shu yerga qo‘ying"
        field.minLines = 4
        field.gravity = Gravity.TOP
        field.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        val paste = tv("📋  Buferdan qo‘yish", 14f, Pal.purple, true)
        paste.setPadding(0, dp(10), 0, dp(6))
        paste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).text?.toString() else null
            if (text.isNullOrBlank()) toast("Bufer bo‘sh") else field.setText(text)
        }
        form.addView(tv("Diqqat: joriy ma’lumotlar zaxira nusxadagi ma’lumotlar bilan almashtiriladi.", 13f, Pal.red))
        form.addView(field)
        form.addView(paste)
        formDialog("Zaxiradan tiklash", form, "Tiklash") {
            if (store.importJson(field.text.toString())) {
                toast("Ma’lumotlar tiklandi")
                navigate(HOME)
                true
            } else {
                toast("Zaxira nusxa matni noto‘g‘ri")
                false
            }
        }
    }

    // ---------------------------------------------------------------- Hisoblar

    private fun accountsPage(): View {
        val col = vbox()
        col.addView(titleBar("Hisoblar va kartalar", "Jami: " + Fmt.money(store.balance), true))
        col.addView(sectionTitle("Mening hisoblarim"))
        val accs = store.accounts()
        for (a in accs) {
            val title = a.name + (if (a.last4.isNotEmpty()) "  ••••" + a.last4 else "")
            col.addView(pad(actionRow(if (a.last4.isNotEmpty()) "💳" else "💵", title, Fmt.money(a.balance), Pal.blue) { accountMenu(a) }, 16, 0, 8))
        }
        val add = tv("+  HISOB / KARTA QO‘SHISH", 15f, Color.WHITE, true)
        add.gravity = Gravity.CENTER
        add.setPadding(0, dp(15), 0, dp(15))
        add.background = bg(Pal.purple, 16)
        add.setOnClickListener { addAccount() }
        col.addView(pad(add, 16, 8, 0))
        val hint = tv("Karta qo‘shganda faqat nomi va oxirgi 4 raqami saqlanadi. To‘liq karta raqami, muddati va CVV kiritilmaydi.", 12f, Pal.gray)
        hint.setPadding(dp(22), dp(14), dp(22), dp(24))
        col.addView(hint)
        return col
    }

    private fun accountMenu(a: Account) {
        val items = arrayOf("✏️  Nom va karta raqamini o‘zgartirish", "⚖️  Balansni to‘g‘rilash", "🗑  O‘chirish")
        AlertDialog.Builder(this)
            .setTitle(a.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> editAccount(a)
                    1 -> adjustAccountBalance(a)
                    else -> deleteAccount(a)
                }
            }
            .show()
    }

    private fun last4Field(initial: String): EditText {
        val e = EditText(this)
        e.hint = "Karta oxirgi 4 raqami (ixtiyoriy)"
        e.setText(initial)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(4))
        return e
    }

    private fun addAccount() {
        val form = formBox()
        val name = textField("Nomi (masalan: Humo – Xalq banki)")
        val last4 = last4Field("")
        val start = moneyField("Boshlang‘ich balans (so‘m)")
        form.addView(caption("NOMI"))
        form.addView(name)
        form.addView(caption("KARTA RAQAMINING OXIRGI 4 TASI"))
        form.addView(last4)
        form.addView(caption("BOSHLANG‘ICH BALANS"))
        form.addView(start)
        formDialog("Yangi hisob / karta", form, "Saqlash") {
            val list = store.accounts()
            val l4 = last4.text.toString().trim()
            if (name.text.isBlank()) {
                toast("Nomini kiriting")
                false
            } else if (l4.isNotEmpty() && l4.length != 4) {
                toast("Karta raqamining oxirgi 4 ta raqamini kiriting")
                false
            } else if (l4.isNotEmpty() && list.any { it.last4 == l4 }) {
                toast("Bu karta allaqachon qo‘shilgan")
                false
            } else {
                list.add(Account(store.nextAccountId(list), name.text.toString().trim(), l4, amountOf(start)))
                store.saveAccounts(list)
                toast("Hisob qo‘shildi")
                render()
                true
            }
        }
    }

    private fun editAccount(a: Account) {
        val form = formBox()
        val name = textField("Nomi", a.name)
        val last4 = last4Field(a.last4)
        form.addView(caption("NOMI"))
        form.addView(name)
        form.addView(caption("KARTA RAQAMINING OXIRGI 4 TASI"))
        form.addView(last4)
        formDialog("Hisobni tahrirlash", form, "Saqlash") {
            val list = store.accounts()
            val l4 = last4.text.toString().trim()
            val i = list.indexOfFirst { it.id == a.id }
            if (name.text.isBlank()) {
                toast("Nomini kiriting")
                false
            } else if (l4.isNotEmpty() && l4.length != 4) {
                toast("Karta raqamining oxirgi 4 ta raqamini kiriting")
                false
            } else if (l4.isNotEmpty() && list.any { it.last4 == l4 && it.id != a.id }) {
                toast("Bu karta boshqa hisobga biriktirilgan")
                false
            } else if (i < 0) {
                false
            } else {
                list[i] = list[i].copy(name = name.text.toString().trim(), last4 = l4)
                store.saveAccounts(list)
                render()
                true
            }
        }
    }

    private fun adjustAccountBalance(a: Account) {
        val form = formBox()
        val field = moneyField("Haqiqiy balans (so‘m)", Math.max(0L, a.balance))
        form.addView(tv("Hisobdagi haqiqiy summani kiriting. Operatsiya yozilmaydi, faqat balans to‘g‘rilanadi.", 13f, Pal.gray))
        form.addView(field)
        formDialog("Balansni to‘g‘rilash", form, "Saqlash") {
            store.setAccountBalance(a.id, amountOf(field))
            toast("Balans yangilandi")
            render()
            true
        }
    }

    private fun deleteAccount(a: Account) {
        val list = store.accounts()
        if (list.size <= 1) {
            toast("Kamida bitta hisob qolishi kerak")
            return
        }
        confirm("Hisobni o‘chirish", "“${a.name}” hisobi o‘chiriladi. Uning operatsiyalari tarixda qoladi, lekin balansga ta’sir qilmaydi.", "Ha, o‘chirish") {
            val cur = store.accounts()
            cur.removeAll { it.id == a.id }
            store.saveAccounts(cur)
            render()
        }
    }

    // ---------------------------------------------------------------- SMS

    private fun hasSmsPermission(): Boolean {
        return checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
    }

    private fun toggleSms() {
        if (!hasSmsPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), SMS_REQUEST)
        } else {
            store.smsAuto = !store.smsAuto
            toast(if (store.smsAuto) "SMS’dan avtomatik qo‘shish yoqildi" else "SMS’dan avtomatik qo‘shish o‘chirildi")
            render()
        }
    }

    private fun importInbox() {
        if (!hasSmsPermission()) {
            pendingImport = true
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), SMS_REQUEST)
            return
        }
        confirm(
            "Eski SMS’larni import qilish",
            "So‘nggi 60 kundagi bank SMS’lari o‘qiladi va operatsiya sifatida qo‘shiladi. Karta balansi eng oxirgi SMS’dagi qoldiqqa moslanadi. Avval qo‘shilgan SMS’lar takrorlanmaydi. Davom etasizmi?",
            "Boshlash"
        ) {
            var added = 0
            var dup = 0
            try {
                val since = System.currentTimeMillis() - 60L * 24L * 3600L * 1000L
                val c = contentResolver.query(
                    Uri.parse("content://sms/inbox"),
                    arrayOf("body", "date"),
                    "date > ?",
                    arrayOf(since.toString()),
                    "date ASC"
                )
                if (c != null) {
                    c.use { cur ->
                        val bi = cur.getColumnIndex("body")
                        val di = cur.getColumnIndex("date")
                        while (cur.moveToNext()) {
                            val text = cur.getString(bi)
                            if (text == null) continue
                            val r = store.applySms(text, cur.getLong(di))
                            if (r.status == 0) added++ else if (r.status == 1) dup++
                        }
                    }
                }
            } catch (e: Exception) {
                toast("SMS’larni o‘qib bo‘lmadi")
            }
            toast("Qo‘shildi: $added ta, takroriy: $dup ta")
            render()
        }
    }

    private fun pasteSms() {
        val form = formBox()
        val field = EditText(this)
        field.hint = "Bank SMS matnini shu yerga qo‘ying"
        field.minLines = 4
        field.gravity = Gravity.TOP
        field.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        val paste = tv("📋  Buferdan qo‘yish", 14f, Pal.purple, true)
        paste.setPadding(0, dp(10), 0, dp(6))
        paste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).text?.toString() else null
            if (text.isNullOrBlank()) toast("Bufer bo‘sh") else field.setText(text)
        }
        form.addView(tv("Bitta yoki bir nechta SMS’ni qo‘yishingiz mumkin (har biri alohida qatorda).", 13f, Pal.gray))
        form.addView(field)
        form.addView(paste)
        formDialog("SMS’ni qo‘shish", form, "Qo‘shish") {
            val whole = field.text.toString()
            val first = store.applySms(whole)
            if (first.status != 2) {
                toast(first.text)
                render()
                true
            } else {
                var added = 0
                var dup = 0
                for (line in whole.split("\n")) {
                    if (line.isBlank()) continue
                    val r = store.applySms(line)
                    if (r.status == 0) added++ else if (r.status == 1) dup++
                }
                if (added == 0 && dup == 0) {
                    toast("SMS tanilmadi. Matnni to‘liq nusxalaganingizni tekshiring.")
                    false
                } else {
                    toast("Qo‘shildi: $added ta, takroriy: $dup ta")
                    render()
                    true
                }
            }
        }
    }
}
