package uz.hisobim.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.widget.Toast

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            val store = Store(context)
            if (!store.smsAuto) return
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
            val body = StringBuilder()
            for (m in msgs) body.append(m.messageBody ?: "")
            val result = store.applySms(body.toString())
            if (result.status == 0) {
                Toast.makeText(context.applicationContext, "HISOBIM: " + result.text, Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            // SMS tahlilida xato bo‘lsa, ilova ishini to‘xtatmaymiz
        }
    }
}
