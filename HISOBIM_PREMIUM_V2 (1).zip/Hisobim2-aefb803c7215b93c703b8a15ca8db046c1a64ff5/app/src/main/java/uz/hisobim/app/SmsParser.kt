package uz.hisobim.app

import java.util.Calendar

class ParsedSms(
    val isIncome: Boolean,
    val amount: Long,
    val balance: Long?,
    val last4: String?,
    val time: Long?,
    val note: String,
    val category: String
)

/** Bank SMS’larini (Humo, Uzcard va boshqalar) tahlil qiladi. */
object SmsParser {
    private const val NUM = "([0-9]+(?:[ .,][0-9]{3})*(?:[.,][0-9]{1,2})?)"
    private val amountRe = Regex("(?i)(?:miqdor|summa|amount|сумма)\\s*[:=]?\\s*" + NUM)
    private val balanceRe = Regex("(?i)(?:qoldiq|balans|balance|остаток|ostatok)\\s*[:=]?\\s*" + NUM)
    private val cardRe = Regex("\\*+\\s*(\\d{4})")
    private val dateRe = Regex("(\\d{2})\\.(\\d{2})\\.(\\d{2,4})\\s+(\\d{1,2}):(\\d{2})")

    private val expenseWords = listOf(
        "chiqim", "spisanie", "списание", "xarid", "purchase", "payment", "оплата",
        "to'lov", "tolov", "yechish", "снятие", "debit"
    )
    private val incomeWords = listOf(
        "kirim", "popolnenie", "пополнение", "zachislenie", "зачисление", "tushum",
        "to'ldirish", "credit", "qaytarildi"
    )

    private fun firstIndex(text: String, words: List<String>): Int {
        var best = Int.MAX_VALUE
        for (w in words) {
            val i = text.indexOf(w)
            if (i >= 0 && i < best) best = i
        }
        return best
    }

    private fun parseNum(raw: String): Long? {
        var t = raw.trim().replace(" ", "")
        val lastDot = t.lastIndexOf('.')
        val lastComma = t.lastIndexOf(',')
        if (lastDot >= 0 && lastComma >= 0) {
            t = if (lastDot > lastComma) t.replace(",", "") else t.replace(".", "").replace(',', '.')
        } else if (lastComma >= 0) {
            t = if (t.length - lastComma - 1 <= 2) t.replace(',', '.') else t.replace(",", "")
        } else if (lastDot >= 0) {
            if (t.length - lastDot - 1 == 3) t = t.replace(".", "")
        }
        val d = t.toDoubleOrNull() ?: return null
        return Math.round(d)
    }

    private fun guessCategory(note: String, income: Boolean): String {
        val n = note.lowercase()
        if (income) {
            return if (n.contains("oylik") || n.contains("maosh") || n.contains("salary") || n.contains("зарплата")) "Oylik" else "Boshqa"
        }
        val food = listOf("korzinka", "makro", "market", "oziq", "food", "kafe", "cafe", "restoran", "restaurant", "evos", "bellissimo", "bozor", "non ", "magnit")
        val transport = listOf("yandex", "taxi", "uber", "mytaxi", "azs", "benzin", "fuel", "metro", "avtobus", "petrol")
        val phone = listOf("ucell", "beeline", "uzmobile", "mobiuz", "humans", "uztelecom", "aloqa", "internet")
        val health = listOf("apteka", "pharm", "clinic", "klinika", "dori", "tibbiyot", "shifoxona")
        val util = listOf("elektr", "gaz", "suv", "kommunal", "hududgaz", "issiqlik")
        for (k in food) if (n.contains(k)) return "Oziq-ovqat"
        for (k in transport) if (n.contains(k)) return "Transport"
        for (k in phone) if (n.contains(k)) return "Aloqa"
        for (k in health) if (n.contains(k)) return "Sog‘liq"
        for (k in util) if (n.contains(k)) return "Kommunal"
        return "Boshqa"
    }

    fun parse(text: String): ParsedSms? {
        val lower = text.lowercase().replace('’', '\'').replace('ʻ', '\'').replace('‘', '\'').replace('`', '\'')
        if (lower.contains("usd") && !lower.contains("uzs")) return null

        val ei = firstIndex(lower, expenseWords)
        val ii = firstIndex(lower, incomeWords)
        if (ei == Int.MAX_VALUE && ii == Int.MAX_VALUE) return null
        val isIncome = ii < ei

        val amountMatch = amountRe.find(text) ?: return null
        val amount = parseNum(amountMatch.groupValues[1]) ?: return null
        if (amount <= 0L) return null

        val balMatch = balanceRe.find(text)
        val balance = if (balMatch != null) parseNum(balMatch.groupValues[1]) else null

        val cardMatch = cardRe.find(text)
        val last4 = cardMatch?.groupValues?.get(1)
        if (last4 == null && balance == null) return null

        var time: Long? = null
        val dm = dateRe.find(text)
        if (dm != null) {
            try {
                var y = dm.groupValues[3].toInt()
                if (y < 100) y += 2000
                val cal = Calendar.getInstance()
                cal.clear()
                cal.set(y, dm.groupValues[2].toInt() - 1, dm.groupValues[1].toInt(), dm.groupValues[4].toInt(), dm.groupValues[5].toInt(), 0)
                time = cal.timeInMillis
            } catch (e: Exception) {
                time = null
            }
        }

        var note = ""
        val colon = text.indexOf(':')
        val end = if (dm != null) dm.range.first else -1
        if (colon >= 0 && end > colon) {
            note = text.substring(colon + 1, end).trim().trim(',').trim()
            note = note.replace(Regex(",\\s*UZ$"), "").trim()
            if (note.length > 60) note = note.substring(0, 60)
        }
        return ParsedSms(isIncome, amount, balance, last4, time, note, guessCategory(note, isIncome))
    }
}
