HISOBIM PREMIUM v2.0 — Android manba loyihasi

Imkoniyatlar:
- Kirim va chiqim: toifa tanlash, izoh, summani avtomatik bo‘shliq bilan formatlash
- O‘tkazma (balansdan yechiladi)
- Kommunal to‘lovlar: elektr, gaz, suv, internet va boshqalar; oylik jami
- Kreditlar: foiz, muddat, oylik to‘lov (bo‘sh qoldirilsa avtomatik hisoblanadi),
  keyingi to‘lov sanasi, qolgan muddat, progress, to‘lov qo‘shish (balansdan yechiladi), o‘chirish
- Bosh sahifada yaqin kredit to‘lovlari eslatmasi (7 kun ichida)
- Hisobot: oylar bo‘yicha (oldingi/keyingi oy), sof natija, jamg‘arma darajasi, ulashish
- Statistika: so‘nggi 6 oy grafigi, o‘rtacha ko‘rsatkichlar
- Taqsimot: toifalar bo‘yicha doira diagramma
- Tarix: qidiruv, turi bo‘yicha filtr, sana bo‘yicha guruhlash, operatsiyani o‘chirish (balans qayta hisoblanadi)
- Oylik xarajat limiti va ogohlantirish
- PIN-kod bilan himoya
- Zaxira nusxa: ulashish, nusxalash, tiklash; barcha ma’lumotlarni tozalash

Yig‘ish:
1. Loyihani Android Studio’da oching va Gradle Sync tugashini kuting.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk
Yoki GitHub’ga yuklab, Actions > "HISOBIM APK Build" > Run workflow.

Talablar: Android Studio, JDK 17, Android SDK 35, AGP 8.7.3, Gradle 8.9+.

Eslatma: bu muhitda Android SDK mavjud emasligi sababli loyiha yig‘ib sinalmagan.
Real ma’lumot kiritishdan oldin qurilmada sinab ko‘ring.
Eski versiya ma’lumotlari (balans, operatsiyalar, kreditlar) avtomatik o‘qiladi.
