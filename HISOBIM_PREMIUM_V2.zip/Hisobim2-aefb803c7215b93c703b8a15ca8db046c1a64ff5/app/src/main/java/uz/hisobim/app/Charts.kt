package uz.hisobim.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

object Pal {
    val purple = Color.rgb(100, 20, 210)
    val purpleDark = Color.rgb(72, 10, 165)
    val gold = Color.rgb(255, 196, 61)
    val green = Color.rgb(20, 160, 90)
    val red = Color.rgb(225, 55, 70)
    val blue = Color.rgb(25, 130, 225)
    val orange = Color.rgb(245, 150, 20)
    val bg = Color.rgb(246, 245, 252)
    val text = Color.rgb(28, 25, 45)
    val gray = Color.rgb(125, 120, 145)
    val line = Color.rgb(232, 230, 242)
    val chart = intArrayOf(
        Color.rgb(100, 20, 210), Color.rgb(25, 130, 225), Color.rgb(20, 160, 90),
        Color.rgb(245, 150, 20), Color.rgb(225, 55, 70), Color.rgb(0, 170, 190),
        Color.rgb(170, 70, 200), Color.rgb(120, 140, 40), Color.rgb(230, 100, 150),
        Color.rgb(110, 110, 130)
    )
}

class PieView(context: Context) : View(context) {
    var values: List<Long> = emptyList()
    var centerTop: String = ""
    var centerBottom: String = ""
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = context.resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val size = Math.min(w, h) * 0.92f
        val rect = RectF((w - size) / 2f, (h - size) / 2f, (w + size) / 2f, (h + size) / 2f)
        var total = 0L
        for (v in values) total += v
        paint.style = Paint.Style.FILL
        if (total <= 0L) {
            paint.color = Pal.line
            canvas.drawArc(rect, 0f, 360f, true, paint)
        } else {
            var start = -90f
            for (i in values.indices) {
                val sweep = values[i].toFloat() / total.toFloat() * 360f
                paint.color = Pal.chart[i % Pal.chart.size]
                canvas.drawArc(rect, start, sweep, true, paint)
                start += sweep
            }
            // bo‘laklar orasidagi ingichka oq chiziq
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * density
            start = -90f
            for (i in values.indices) {
                val sweep = values[i].toFloat() / total.toFloat() * 360f
                canvas.drawArc(rect, start, sweep, true, paint)
                start += sweep
            }
            paint.style = Paint.Style.FILL
        }
        paint.color = Color.WHITE
        canvas.drawCircle(w / 2f, h / 2f, size * 0.30f, paint)

        paint.textAlign = Paint.Align.CENTER
        paint.color = Pal.gray
        paint.textSize = 12f * density
        paint.isFakeBoldText = false
        canvas.drawText(centerTop, w / 2f, h / 2f - 4f * density, paint)
        paint.color = Pal.text
        paint.textSize = 15f * density
        paint.isFakeBoldText = true
        canvas.drawText(centerBottom, w / 2f, h / 2f + 16f * density, paint)
        paint.isFakeBoldText = false
    }
}

class BarChartView(context: Context) : View(context) {
    var labels: List<String> = emptyList()
    var income: List<Long> = emptyList()
    var expense: List<Long> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = context.resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val n = labels.size
        if (n == 0 || income.size < n || expense.size < n) return
        val w = width.toFloat()
        val h = height.toFloat()
        val yTop = 18f * density
        val yBot = h - 26f * density
        var max = 1L
        for (i in 0 until n) max = Math.max(max, Math.max(income[i], expense[i]))

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = density
        paint.color = Pal.line
        for (g in 0..3) {
            val y = yTop + (yBot - yTop) * g / 3f
            canvas.drawLine(0f, y, w, y, paint)
        }
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 10f * density
        paint.color = Pal.gray
        canvas.drawText(Fmt.short(max), 2f * density, yTop - 4f * density, paint)

        val slot = w / n
        val barW = slot * 0.26f
        val gap = 1.5f * density
        for (i in 0 until n) {
            val cx = slot * i + slot / 2f
            val ih = (yBot - yTop) * income[i].toFloat() / max.toFloat()
            val eh = (yBot - yTop) * expense[i].toFloat() / max.toFloat()
            paint.color = Pal.green
            canvas.drawRoundRect(RectF(cx - barW - gap, yBot - ih, cx - gap, yBot), 4f * density, 4f * density, paint)
            paint.color = Pal.red
            canvas.drawRoundRect(RectF(cx + gap, yBot - eh, cx + gap + barW, yBot), 4f * density, 4f * density, paint)
            paint.color = Pal.gray
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 11f * density
            canvas.drawText(labels[i], cx, h - 8f * density, paint)
        }
    }
}
