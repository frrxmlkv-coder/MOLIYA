package uz.hisobim.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Types {
    const val INCOME = "Kirim"
    const val EXPENSE = "Chiqim"
    const val TRANSFER = "O‘tkazma"
    const val CREDIT = "Kredit to‘lovi"
}

object Cats {
    val expense = listOf(
        "Oziq-ovqat", "Transport", "Kommunal", "Uy-joy", "Sog‘liq", "Ta’lim",
        "Kiyim-kechak", "Ko‘ngilochar", "Aloqa", "Sovg‘a", "Boshqa"
    )
    val income = listOf(
        "Oylik", "Biznes", "Qo‘shimcha daromad", "Sovg‘a", "Qarz qaytarildi", "Boshqa"
    )
    val utilities = listOf(
        "Elektr energiyasi", "Tabiiy gaz", "Suv", "Internet", "Telefon", "Chiqindi", "Isitish", "Boshqa"
    )
    val creditTypes = listOf("Iste’mol krediti", "Avtokredit", "Ipoteka", "Ta’lim krediti", "Mikroqarz", "Boshqa")

    fun icon(name: String): String {
        return when (name) {
            "Oziq-ovqat" -> "🛒"
            "Transport" -> "🚗"
            "Kommunal" -> "💡"
            "Uy-joy" -> "🏠"
            "Sog‘liq" -> "💊"
            "Ta’lim" -> "🎓"
            "Kiyim-kechak" -> "👕"
            "Ko‘ngilochar" -> "🎬"
            "Aloqa" -> "📱"
            "Sovg‘a" -> "🎁"
            "Oylik" -> "💼"
            "Biznes" -> "📈"
            "Qo‘shimcha daromad" -> "💵"
            "Qarz qaytarildi" -> "🤝"
            "Daromad" -> "💰"
            "O‘tkazma" -> "🔁"
            "Kredit" -> "🏦"
            "Elektr energiyasi" -> "⚡"
            "Tabiiy gaz" -> "🔥"
            "Suv" -> "💧"
            "Internet" -> "🌐"
            "Telefon" -> "📞"
            "Chiqindi" -> "🗑"
            "Isitish" -> "♨"
            else -> "💳"
        }
    }
}

object Fmt {
    val months = arrayOf(
        "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
        "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"
    )

    val shortMonths = arrayOf(
        "Yan", "Fev", "Mar", "Apr", "May", "Iyn",
        "Iyl", "Avg", "Sen", "Okt", "Noy", "Dek"
    )

    fun group(v: Long): String {
        val neg = v < 0
        val s = Math.abs(v).toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            if (i > 0 && (s.length - i) % 3 == 0) sb.append(' ')
            sb.append(s[i])
        }
        return (if (neg) "-" else "") + sb.toString()
    }

    fun money(v: Long): String = group(v) + " so‘m"

    fun moneyD(v: Double): String = money(Math.round(v))

    fun short(v: Long): String {
        return when {
            v >= 1000000000L -> String.format(Locale.US, "%.1f mlrd", v / 1000000000.0)
            v >= 1000000L -> String.format(Locale.US, "%.1f mln", v / 1000000.0)
            v >= 1000L -> String.format(Locale.US, "%d ming", v / 1000L)
            else -> v.toString()
        }
    }

    fun monthName(year: Int, month: Int): String = months[month] + " " + year

    fun dateTime(t: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(t))

    fun dateOnly(t: Long): String = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(t))

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun isValidDate(s: String): Boolean {
        return try {
            val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            f.isLenient = false
            f.parse(s.trim()) != null && s.trim().length == 10
        } catch (e: Exception) {
            false
        }
    }
}

data class Tx(
    val id: Long,
    val type: String,
    val amount: Long,
    val category: String,
    val note: String,
    val time: Long
) {
    val isIncome: Boolean get() = type == Types.INCOME

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("type", type)
        o.put("amount", amount)
        o.put("category", category)
        o.put("note", note)
        o.put("time", time)
        return o
    }

    companion object {
        fun from(o: JSONObject): Tx {
            val type = o.optString("type", Types.EXPENSE)
            val time = o.optLong("time", 0L)
            var note = o.optString("note", "")
            if (note == "Daromad" || note == "Xarajat") note = ""
            var cat = o.optString("category", "")
            if (cat.isBlank()) {
                cat = when (type) {
                    Types.INCOME -> "Daromad"
                    Types.TRANSFER -> "O‘tkazma"
                    Types.CREDIT -> "Kredit"
                    else -> "Boshqa"
                }
            }
            return Tx(o.optLong("id", time), type, o.optLong("amount", 0L), cat, note, time)
        }
    }
}

data class Credit(
    val name: String,
    val type: String,
    val total: Double,
    val rate: Double,
    val months: Int,
    val monthly: Double,
    val startDate: String,
    val paymentDay: Int,
    val paid: Double,
    val purpose: String
) {
    val left: Double get() = (total - paid).coerceAtLeast(0.0)
    val progress: Int
        get() = if (total > 0) ((paid / total) * 100).toInt().coerceIn(0, 100) else 0

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("name", name)
        o.put("type", type)
        o.put("total", total)
        o.put("rate", rate)
        o.put("months", months)
        o.put("monthly", monthly)
        o.put("startDate", startDate)
        o.put("paymentDay", paymentDay)
        o.put("paid", paid)
        o.put("purpose", purpose)
        return o
    }

    companion object {
        fun from(o: JSONObject): Credit {
            val rate = o.optString("rate", "0").replace(',', '.').toDoubleOrNull() ?: 0.0
            var day = o.optInt("paymentDay", 1)
            if (day < 1 || day > 31) day = 1
            return Credit(
                o.optString("name", "Kredit"),
                o.optString("type", ""),
                o.optDouble("total", 0.0),
                rate,
                o.optInt("months", 0),
                o.optDouble("monthly", 0.0),
                o.optString("startDate", ""),
                day,
                o.optDouble("paid", 0.0),
                o.optString("purpose", "")
            )
        }
    }
}

class Summary(val income: Long, val expense: Long, val transfer: Long, val credit: Long, val count: Int) {
    val out: Long get() = expense + transfer + credit
    val net: Long get() = income - out
}

fun summarize(list: List<Tx>): Summary {
    var inc = 0L
    var exp = 0L
    var tr = 0L
    var cr = 0L
    for (t in list) {
        when (t.type) {
            Types.INCOME -> { inc += t.amount }
            Types.EXPENSE -> { exp += t.amount }
            Types.TRANSFER -> { tr += t.amount }
            else -> { cr += t.amount }
        }
    }
    return Summary(inc, exp, tr, cr, list.size)
}

fun monthKey(t: Long): Int {
    val c = Calendar.getInstance()
    c.timeInMillis = t
    return c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)
}

fun monthTx(all: List<Tx>, year: Int, month: Int): List<Tx> {
    val k = year * 12 + month
    return all.filter { monthKey(it.time) == k }
}

/** Barcha chiqimlar (xarajat, o‘tkazma, kredit) bo‘yicha toifa yig‘indilari, kamayish tartibida. */
fun outflowByCategory(list: List<Tx>): List<Pair<String, Long>> {
    val map = LinkedHashMap<String, Long>()
    for (t in list) {
        if (t.isIncome) continue
        map[t.category] = (map[t.category] ?: 0L) + t.amount
    }
    return map.entries.map { Pair(it.key, it.value) }.sortedByDescending { it.second }
}

fun annuity(total: Double, ratePct: Double, n: Int): Double {
    if (n <= 0) return 0.0
    val r = ratePct / 100.0 / 12.0
    return if (r == 0.0) total / n else total * r / (1 - Math.pow(1 + r, -n.toDouble()))
}

fun startOfToday(): Calendar {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c
}

/** Kreditning keyingi to‘lov sanasi (qarz qolmagan bo‘lsa null). */
fun nextPayment(c: Credit): Calendar? {
    if (c.left <= 0.0) return null
    val today = startOfToday()
    val cal = today.clone() as Calendar
    cal.set(Calendar.DAY_OF_MONTH, 1)
    cal.set(Calendar.DAY_OF_MONTH, Math.min(c.paymentDay, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
    if (cal.before(today)) {
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, 1)
        cal.set(Calendar.DAY_OF_MONTH, Math.min(c.paymentDay, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
    }
    return cal
}

fun daysUntil(cal: Calendar): Int {
    val diff = cal.timeInMillis - startOfToday().timeInMillis
    return Math.round(diff / 86400000.0).toInt()
}

class Store(context: Context) {
    private val p = context.getSharedPreferences("hisobim", Context.MODE_PRIVATE)

    var balance: Long
        get() = p.getLong("balance", 0L)
        set(v) {
            p.edit().putLong("balance", v).apply()
        }

    var budget: Long
        get() = p.getLong("budget", 0L)
        set(v) {
            p.edit().putLong("budget", v).apply()
        }

    private fun hash(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(("hisobim:" + s).toByteArray())
        val sb = StringBuilder()
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun hasPin(): Boolean = (p.getString("pin", "") ?: "").isNotEmpty()

    fun setPin(pin: String?) {
        if (pin == null || pin.isEmpty()) p.edit().remove("pin").apply()
        else p.edit().putString("pin", hash(pin)).apply()
    }

    fun checkPin(pin: String): Boolean = (p.getString("pin", "") ?: "") == hash(pin)

    fun transactions(): MutableList<Tx> {
        val arr = try {
            JSONArray(p.getString("transactions", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<Tx>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Tx.from(o))
        }
        return out
    }

    private fun saveTransactions(list: List<Tx>) {
        val arr = JSONArray()
        for (t in list) arr.put(t.toJson())
        p.edit().putString("transactions", arr.toString()).apply()
    }

    private fun delta(type: String, amount: Long): Long = if (type == Types.INCOME) amount else -amount

    fun addTx(type: String, amount: Long, category: String, note: String): Tx {
        val now = System.currentTimeMillis()
        val tx = Tx(now, type, amount, category, note, now)
        val list = transactions()
        list.add(tx)
        saveTransactions(list)
        balance += delta(type, amount)
        return tx
    }

    fun deleteTx(id: Long) {
        val list = transactions()
        val found = list.firstOrNull { it.id == id } ?: return
        list.remove(found)
        saveTransactions(list)
        balance -= delta(found.type, found.amount)
    }

    fun credits(): MutableList<Credit> {
        val arr = try {
            JSONArray(p.getString("credits", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<Credit>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Credit.from(o))
        }
        return out
    }

    fun saveCredits(list: List<Credit>) {
        val arr = JSONArray()
        for (c in list) arr.put(c.toJson())
        p.edit().putString("credits", arr.toString()).apply()
    }

    /** Xato bo‘lsa matn, muvaffaqiyatli bo‘lsa null qaytaradi. */
    fun payCredit(index: Int, amount: Long): String? {
        val list = credits()
        if (index < 0 || index >= list.size) return "Kredit topilmadi"
        val c = list[index]
        if (amount <= 0) return "To‘lov summasini kiriting"
        if (amount > Math.ceil(c.left).toLong()) return "To‘lov qolgan qarzdan oshib ketdi"
        if (amount > balance) return "Balansda mablag‘ yetarli emas"
        list[index] = c.copy(paid = c.paid + amount)
        saveCredits(list)
        addTx(Types.CREDIT, amount, "Kredit", c.name)
        return null
    }

    fun exportJson(): String {
        val o = JSONObject()
        o.put("app", "hisobim")
        o.put("version", 2)
        o.put("balance", balance)
        o.put("budget", budget)
        val tx = JSONArray()
        for (t in transactions()) tx.put(t.toJson())
        o.put("transactions", tx)
        val cr = JSONArray()
        for (c in credits()) cr.put(c.toJson())
        o.put("credits", cr)
        return o.toString()
    }

    fun importJson(text: String): Boolean {
        return try {
            val o = JSONObject(text.trim())
            if (!o.has("transactions") && !o.has("credits")) return false
            val tx = o.optJSONArray("transactions") ?: JSONArray()
            val cr = o.optJSONArray("credits") ?: JSONArray()
            p.edit()
                .putLong("balance", o.optLong("balance", 0L))
                .putLong("budget", o.optLong("budget", 0L))
                .putString("transactions", tx.toString())
                .putString("credits", cr.toString())
                .apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun resetAll() {
        p.edit().clear().apply()
    }
}
